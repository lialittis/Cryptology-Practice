/*! \file random.h
 */

unsigned int random_seed();
